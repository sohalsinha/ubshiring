package banking;

public class Company  {
	private String companyName;

	public Company(String companyName, int taxId) {
		// complete the function
	}

	public String getCompanyName() {
		// complete the function
        return null;
	}
}
